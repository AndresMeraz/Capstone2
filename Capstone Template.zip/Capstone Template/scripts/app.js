"use strict";

//Declaring variables
console.log(locationsArray.length);
